/*
5. Write a program to print Fibonacci series.
*/
import java.util.Scanner;

public class FibonacciSeries {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("How many terms? ");
        int n = sc.nextInt();
        int a = 0, b = 1;
        for (int i = 1; i <= n; i++) {
            System.out.print(a + (i==n? "\n" : " "));
            int c = a + b;
            a = b;
            b = c;
        }
        sc.close();
    }
}
