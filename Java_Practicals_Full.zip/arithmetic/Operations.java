/*
14. Create a package called 'Arithmetic' that contains methods to deal all arithmetic operations. Also write a program to use the package.
This file belongs to the package.
*/
package arithmetic;

public class Operations {
    public static int add(int a, int b) { return a + b; }
    public static int sub(int a, int b) { return a - b; }
    public static int mul(int a, int b) { return a * b; }
    public static double div(int a, int b) {
        if (b == 0) throw new ArithmeticException("Divide by zero");
        return (double)a / b;
    }
}
